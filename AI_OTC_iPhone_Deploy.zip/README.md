# AI OTC Scanner Mobile

Proyecto preparado para abrirse desde iPhone. La web móvil consume `/api/candles`; el servidor obtiene datos mediante el cliente comunitario no oficial de Pocket Option.

## Despliegue
1. Sube esta carpeta a un repositorio privado.
2. Despliega el servicio Python con `render.yaml` o equivalente.
3. Define `PO_SSID` como variable secreta del servidor. Nunca la pongas en el HTML ni la compartas.
4. Define `PO_ASSET` (por defecto EURUSD_otc).
5. Abre la URL HTTPS del servidor desde el iPhone.
6. Pulsa CONECTAR.

Empieza en DEMO. Esta integración es no oficial y puede romperse si cambia el protocolo de Pocket Option. No incluye ejecución automática de operaciones.
